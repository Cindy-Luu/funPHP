
You are logged in.
<br>Your password is salted and hashed! YAY! 
<Br>Please don't forget to logout!

<a href="secureLogout.php?logout">Logout</a>
