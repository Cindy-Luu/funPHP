<?php

session_start(); 
if (isset($_GET["logout"])){
        
    session_destroy();
    echo "Logged out.";
	}else{
	//$_SESSION = array();		
	session_destroy();  
	echo "You are logged out.";
	}
		
?>
