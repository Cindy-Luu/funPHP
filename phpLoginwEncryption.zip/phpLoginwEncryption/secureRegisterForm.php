<?php

$usernameErr = $passwordErr = $emailErr = "";
$username = $password = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username"])) {
    $nameErr = "Username is required";
  } else {
    $username = test_input($_POST["username"]);
    // check if username only contains letters and numbers
    if (!preg_match("/^[a-z\d]{2,64}$/i",$username)) {
      $usernameErr = "Only letters and white space allowed"; 
    }
  } 
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
 
  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = test_input($_POST["password"]);
    // check if password is well-formed
    if (!filter_var($password, FILTER_SANITIZE_STRING)) {
      $passwordErr = "Invalid password format"; 
    }
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>


<!-- register form -->
<form method="post" action="secureRegister.php" name="secureRegisterForm">

Userame: <input class="login_input" type="text" pattern="{2,10}" name="username" required autocomplete="off" />
  <span class="error">* <?php echo $usernameErr;?></span>
  <br><br>

E-mail: <input class="login_input" type="email" name="email" required autocomplete="off" />
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>

Password: <input id="login_input_password" class="login_input" type="password" name="password" pattern=".{8,}" required autocomplete="off" />
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>	
   
<input type="submit"  name="register" value="Register" />

</form>

<!-- backlink -->
<a href="secureIndex.php">Back to Login Page</a>
