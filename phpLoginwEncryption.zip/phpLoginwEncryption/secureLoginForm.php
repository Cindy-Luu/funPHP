<?php

$usernameErr = $passwordErr = $emailErr = "";
$username = $password = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username"])) {
    $nameErr = "Required";
  } else {
    $username = test_input($_POST["username"]);
    // check if username only contains letters and numbers	
    if (!preg_match("/^[a-z\d]{2,64}$/i",$username)) {
      $usernameErr = "Only letters and white space allowed"; 
    }
  } 
  
  if (empty($_POST["password"])) {
    $passwordErr = "Required";
  } else {
    $password = test_input($_POST["password"]);
    // check if password is well-formed
    if (!filter_var($password, FILTER_SANITIZE_STRING)) {
      $passwordErr = "Invalid password format"; 
    }
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<!-- login form box -->
<form method="post" action="secureIndex.php" name="loginform">

Userame: <input class="login_input" type="text" pattern="{2,10}" name="username" required autocomplete="off" />
  <span class="error">* <?php echo $usernameErr;?></span>
  <br><br>

Password: <input id="login_input_password" class="login_input" type="password" name="password" pattern=".{8,}" required autocomplete="off" />
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>	

<input type="submit"  name="login" value="Log in" />

</form>

<a href="secureRegisterForm.php">Register new account</a>
