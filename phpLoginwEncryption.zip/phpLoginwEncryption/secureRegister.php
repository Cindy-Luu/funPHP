<?php

include_once("param.php");

if (!empty($_POST['username'])          
    && preg_match('/^[a-z\d]{2,64}$/i', $_POST['username'])
    && strlen($_POST['email']) <= 64
    && !empty($_POST['password'])                       
    ) { 
	//database connect
	$conn = new mysqli(hostname, dbusername, dbpassword, database_name);
        if (!$conn->connect_errno) {
			//escaping html code
			$username = $conn->real_escape_string(strip_tags($_POST['username'], ENT_QUOTES));
			$email = $conn->real_escape_string(strip_tags($_POST['email'], ENT_QUOTES));
			$password = $_POST['password']; 						
			//salt and hashing password with bcrypt	
			$user_password_hash = password_hash($password, PASSWORD_DEFAULT);				
			//check if user or email address already exists
			$sql = "SELECT * FROM users WHERE user_name = '" . $username . "' OR user_email = '" . $email . "';";
			$check_username = $conn->query($sql);
			if ($check_username->num_rows == 1) {
				echo "Sorry, the username or email is already taken.";
			} else {
				//write data into database
				$sql = "INSERT INTO users (user_name, user_password_hash, user_email)
                    VALUES('" . $username . "', '" . $user_password_hash . "', '" . $email . "');";
				$query_new_user_insert = $conn->query($sql);
				if ($query_new_user_insert) {
					echo "Welcome.";
				} else {
					echo "Error. Please try again.";
				}
			}
        } else {
            echo "No connection.";
        }
    } else {
            echo "Error occurred.";
    }    
include("secureIndex.php");

?>