<?php

include_once("param.php");

if (!empty($_POST['username']) && !empty($_POST['password'])) {
            // create connection
            $conn = new mysqli(hostname, dbusername, dbpassword, database_name);
            // if no connection
            if (!$conn->connect_errno) {
                $username = $conn->real_escape_string($_POST['username']);                
                $sql = "SELECT user_name, user_email, user_password_hash FROM users WHERE user_name = '" . $username . "' ;";            
				$login_check = $conn->query($sql);
                if ($login_check->num_rows == 1) {
                    $result_row = $login_check->fetch_object();
                    // hashing password
                    if (password_verify($_POST['password'], $result_row->user_password_hash)) {
					$result =mysqli_query($conn, $sql);
					while ($row = mysqli_fetch_assoc($result)){
						printf ("Welcome ");
						printf ("%s\n", $row['user_name']);
						printf (".");;
					}
					mysqli_close($conn);						
					include("secureHomepage.php");
                    } else {
                        echo "Please try again.";
                    }
                } else {
                    echo "User does not exist.";
                }
            } else {
                echo "No connection.";
            }
        }  else {
                include("secureLoginForm.php");
            }              				
			
?>