<?php

define("hostname", "127.0.0.1");
define("database_name", "login");
define("dbusername", "cindyatUmucMysql");
define("dbpassword", "_S1mpl3P@ssw0rd_");

?>